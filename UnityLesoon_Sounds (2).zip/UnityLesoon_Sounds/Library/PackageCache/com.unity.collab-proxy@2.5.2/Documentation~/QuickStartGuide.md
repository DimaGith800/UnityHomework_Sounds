# Quick start guide

The Version Control package provides an integration of Unity Version Control (Unity VCS, formerly Plastic SCM) in the Unity Editor.

[Get started with Unity Version Control](GetStarted.md)
