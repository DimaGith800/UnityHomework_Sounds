using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class audiocontrol : MonoBehaviour
{
    public AudioSource audioSource;

    public void ChangeVolume(Slider slider)
    {
        audioSource.volume = slider.value;
    }
}
