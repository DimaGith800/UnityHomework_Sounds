using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class buttonaudio : MonoBehaviour
{
    public AudioSource audioSource;

    public void MuteOnClick(Button button)
    {
        audioSource.volume = 0;
    }
    public void UnmuteOnClick(Button button)
    {
        audioSource.volume = 1;
    }

}
